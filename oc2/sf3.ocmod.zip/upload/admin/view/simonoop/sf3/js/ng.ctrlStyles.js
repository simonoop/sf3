app.controller('ctrlStyles',['$scope','$http','$log','env','$cacheFactory', function($scope,$http,$log,$env,$cacheFactory){
   
    $scope.previewURL='http://ocsf3.com/index.php?route=module/sf3/preview&category_id=20';
   
}]);


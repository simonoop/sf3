app.controller('ctrlHireme',['$scope','$http','$log','env', function($scope,$http,$log,$env){
}]);


<div class="view-title">About</div>

<table class="form">
    <tr>
        <td>Version</td>
        <td>
            {{about.version}}
        </td>
    </tr>
    <tr>
        <td>License</td>
        <td>
            {{about.license}}
        </td>
    </tr>
    <tr>
        <td>Credits</td>
        <td>
            <table>
                <tr>
                    <td><h2>ion.rangeSlider</h2></td>
                    <td>
                        <a href="https://github.com/IonDen/ion.rangeSlider">https://github.com/IonDen/ion.rangeSlider</a>    
                    </td>
                </tr>
                <tr>
                    <td><h3>jquery.slimscroll</h3></td>
                    <td><a href="http://rocha.la/jQuery-slimScroll/">http://rocha.la/jQuery-slimScroll/</a></td>
                </tr>
                <tr>
                    <td><h3>tooltipster</h3></td>
                    <td><a href="http://iamceege.github.io/tooltipster/">http://iamceege.github.io/tooltipster//</a></td>
                </tr>                
            </table>

        </td>
    </tr>        
</table>
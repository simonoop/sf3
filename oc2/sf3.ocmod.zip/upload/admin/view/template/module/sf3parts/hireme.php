<div class="view-title">Hire me!</div>

<table class="form">
    
    <tr>
        <td>Credits</td>
        <td>
            <table>
                <tr>
                    <td><h3>ion.rangeSlider</h3></td>
                    <td>
                        <a href="https://github.com/IonDen/ion.rangeSlider">https://github.com/IonDen/ion.rangeSlider</a>    
                    </td>
                </tr>
                <tr>
                    <td><h3>jquery.slimscroll</h3></td>
                    <td><a href="http://rocha.la/jQuery-slimScroll/">http://rocha.la/jQuery-slimScroll/</a></td>
                </tr>
                <tr>
                    <td><h3>tooltipster</h3></td>
                    <td><a href="http://iamceege.github.io/tooltipster/">http://iamceege.github.io/tooltipster//</a></td>
                </tr>                
                <tr>
                    <td><h3>Readmore.js</h3></td>
                    <td><a href="http://www.jqueryscript.net/demo/Lightweight-jQuery-Read-More-Link-Plugin-Readmore-js/">http://www.jqueryscript.net/demo/Lightweight-jQuery-Read-More-Link-Plugin-Readmore-js/</a></td>
                </tr>                
            </table>

        </td>
    </tr>        
</table>